﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Timer_Script : MonoBehaviour
{

    public static bool beginning = true;
    public float duration = 60.0f;
    public float time;
    public bool countDown = false;
    Text timeLeft;

	// Use this for initialization
	void Start ()
    {
        if (!countDown)
        {
            countDown = true;
            timeLeft = GetComponent<Text>();
            time = duration;
            Invoke("time_tick", 1f);
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
        timeLeft.text = "Time: " + time;
        if(time == 0)
        {
           
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex -1);
           

        }
	}

  

    private void time_tick()
    {
        time--;
        if(time > 0)
        {
            Invoke("time_tick", 1f);
        }
        else
        {
            countDown = false;
        }
    }
}
