﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class EnemyMovement : MonoBehaviour
{

// Speed in units per sec
public float speed;
//public Vector3 endPoint;

private void Update()
    {
        // The step size is equal to speed times frame time.
        float step = speed * Time.deltaTime;
    
        transform.position += transform.up * step;
    }



}