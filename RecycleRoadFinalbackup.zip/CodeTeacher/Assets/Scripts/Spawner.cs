﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject enemy;
    public GameObject pickup;
    // The enemy prefab to be spawned.
    public float spawnTime = 2f;            // How long between each spawn.
 
    


    void Start()
    {
        // Call the Spawn function after a delay of the spawnTime and then continue to call after the same amount of time.
        InvokeRepeating("Spawn", spawnTime, spawnTime);
        
    }
    void Spawn()
    {
        // GameObject clone;
        // clone = 
        int randomNumber = Random.Range(1, 10);

        if (randomNumber < 5)
        {
            Instantiate(pickup, transform.position, transform.rotation);
        }
        else
        {
            Instantiate(enemy, transform.position, transform.rotation);
        }
    
       
      //  enemy.gameObject.SetActive(true);
        // Create an instance of the enemy prefab at the randomly selected spawn point's position and rotation.

    }

}