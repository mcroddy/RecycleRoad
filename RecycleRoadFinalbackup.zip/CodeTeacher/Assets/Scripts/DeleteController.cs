﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteController : MonoBehaviour {

    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.CompareTag("Enemy"))
        {

            print("deleted");
            //other.gameObject.SetActive(false);
            Destroy(other.gameObject);
        }
        else if (other.gameObject.CompareTag("Pickup"))
        {
            print("deleted");
            //other.gameObject.SetActive(false);
            Destroy(other.gameObject);
        }


    }
}
